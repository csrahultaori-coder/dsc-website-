/* DSC Suvidha Kendra — site interactions */
(function(){
  var WA_NUMBER = "918828368033"; // primary WhatsApp number, international format

  // Mobile nav toggle
  document.addEventListener('click', function(e){
    var burger = e.target.closest('.hamburger');
    if(burger){
      var nav = document.querySelector('.main-nav');
      nav.classList.toggle('open');
    } else if(!e.target.closest('.main-nav')){
      var nav2 = document.querySelector('.main-nav');
      if(nav2) nav2.classList.remove('open');
    }
  });

  // Generic enquiry forms -> build WhatsApp message
  document.querySelectorAll('form[data-lead-form]').forEach(function(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      var data = new FormData(form);
      var name = data.get('name') || '';
      var phone = data.get('phone') || '';
      var service = data.get('service') || form.getAttribute('data-service') || 'Digital Signature Certificate';
      var city = data.get('city') || '';
      var msg = "Hello DSC Suvidha Kendra, I would like to enquire about *" + service + "*.%0AName: " + encodeURIComponent(name) + "%0APhone: " + encodeURIComponent(phone) + (city ? "%0ACity: " + encodeURIComponent(city) : "");
      var url = "https://wa.me/" + WA_NUMBER + "?text=" + msg;
      var thankBox = form.parentElement.querySelector('.form-thanks');
      if(thankBox){ thankBox.style.display = 'block'; }
      window.open(url, '_blank');
      form.reset();
    });
  });

  // Lead capture popup — show once per session after delay / exit intent
  var popup = document.getElementById('leadPopup');
  if(popup){
    var shown = sessionStorage.getItem('dsc_popup_shown');
    function openPopup(){
      if(sessionStorage.getItem('dsc_popup_shown')) return;
      popup.classList.add('show');
      sessionStorage.setItem('dsc_popup_shown','1');
    }
    setTimeout(openPopup, 18000);
    document.addEventListener('mouseout', function(e){
      if(!e.relatedTarget && e.clientY < 10) openPopup();
    });
    popup.addEventListener('click', function(e){
      if(e.target.classList.contains('modal-overlay') || e.target.classList.contains('modal-close')){
        popup.classList.remove('show');
      }
    });
  }

  // Side tab opens popup manually too
  document.querySelectorAll('[data-open-popup]').forEach(function(btn){
    btn.addEventListener('click', function(){
      if(popup) popup.classList.add('show');
    });
  });

  // Set year in footer
  document.querySelectorAll('.cur-year').forEach(function(el){ el.textContent = new Date().getFullYear(); });
})();
